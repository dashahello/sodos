export interface PermissionInterface {
  id?: number;
  owner: number;
  visitor: number;
}
