export class PermissionRequestnDto {
  ownerId: number;
  visitorId: number;
}
