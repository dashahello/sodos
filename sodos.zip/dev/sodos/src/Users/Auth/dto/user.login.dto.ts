export class UserLoginDto {
  readonly username?: string;
  readonly password?: string;
}
